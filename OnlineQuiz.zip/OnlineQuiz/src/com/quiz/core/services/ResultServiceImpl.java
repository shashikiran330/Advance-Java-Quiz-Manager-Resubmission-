package com.quiz.core.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.quiz.core.daos.ResultDao;
import com.quiz.core.exceptions.ResultException;
import com.quiz.core.models.Result;
import com.quiz.core.models.Student;

@Service
@Transactional(propagation = Propagation.REQUIRES_NEW)
public class ResultServiceImpl implements ResultService {
	@Autowired
	private ResultDao dao;
	@Override
	public ArrayList<Student> fetchRecords(String technology,String level,String state,String city) throws ResultException {
		return dao.getResultList(technology,level,state,city);
	}
 
}
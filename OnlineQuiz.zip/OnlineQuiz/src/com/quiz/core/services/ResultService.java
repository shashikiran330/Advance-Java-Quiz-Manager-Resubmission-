package com.quiz.core.services;

import java.util.ArrayList;

import com.quiz.core.exceptions.ResultException;
import com.quiz.core.models.Student;

public interface ResultService {

public ArrayList<Student> fetchRecords(String technology,String level,String state,String city) throws ResultException;
}
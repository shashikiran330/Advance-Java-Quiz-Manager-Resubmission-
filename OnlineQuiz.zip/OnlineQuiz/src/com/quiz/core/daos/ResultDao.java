package com.quiz.core.daos;

import java.util.ArrayList;

import com.quiz.core.exceptions.ResultException;
import com.quiz.core.models.Student;


public interface ResultDao {
		ArrayList<Student> getResultList(String technology,String level,String state,String city) throws ResultException;
}
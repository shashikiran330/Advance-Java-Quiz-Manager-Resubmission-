package com.quiz.core.daos;

import java.util.ArrayList;

import com.quiz.core.exceptions.StudentException;
import com.quiz.core.models.Exam;
import com.quiz.core.models.Question;
import com.quiz.core.models.Result;
import com.quiz.core.models.Student;

public interface StudentDao {
	public Student insertNewStudent(Student student, String strStudentEmail, String strStudentPassword) throws StudentException;
	
	public Integer authenticate(String studentId, String studentPass) throws StudentException;
	
	public ArrayList<Exam> getExamListByStudentId(Integer studentId) throws StudentException;
	
	public ArrayList<Question> getQuestionByExamId(Integer examId) throws StudentException;
	
	public String updateStudentScore(Integer examId, Integer studentId, Integer resultScore) throws StudentException;
	
	public ArrayList<Result> viewResultsOfStudentId(Integer studentId) throws StudentException;
	
}
